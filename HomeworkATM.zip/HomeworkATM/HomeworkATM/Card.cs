﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace HomeworkATM
{
    internal class Card
    {
        public string CardNum { get; }
        public string Owner { get; }
        public string MonthYearOfEnd { get; }
        public string BankIssuer { get; }

        public double Balance;
        
        public Card (string cardnum, string owner,string monthyearofend, string bankissuer, double balance)
        {
            try
            {
                if ((cardnum.Length != 16) & (cardnum.All(x => char.IsDigit(x))))
                {
                    throw new ArgumentException("Wrong caed number");
                }

                if (balance < 0)
                {
                    throw new ArgumentException("Balance can't be negative");
                }

                if ((monthyearofend.Length!=5) || (!monthyearofend.Contains("/")) )
                {
                    throw new ArgumentException("Wrong date format");
                }

            } catch { }

            this.CardNum = cardnum;
            this.Owner = owner;
            this.BankIssuer = bankissuer;
            this.Balance = balance;
            this.MonthYearOfEnd = monthyearofend;
        }

        public override string ToString() => $"Номер карты {CardNum}, владелец - {Owner}, срок службы карты кончится {MonthYearOfEnd} , Банк{BankIssuer} , Баланс{Balance}";
        
         
        
    }
}
