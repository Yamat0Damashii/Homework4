﻿using System.Text.RegularExpressions;

namespace HomeworkATM
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
            var a = new Card("1234567891011123", "MaximOrlach", "04/29", "Тинькофф", 3820);
            var b = new ATM("Сбербанк");
            Console.WriteLine(a.ToString());
            Console.WriteLine(b.ToString());
            Replenishment(a, b, GetBanknotes(Console.ReadLine()));
            Console.WriteLine(a.ToString());
            Console.WriteLine(b.ToString());
            Withdrawal(a, b, CheckSum(Console.ReadLine()));
            Console.WriteLine(a.ToString());
            Console.WriteLine(b.ToString());
            PickUp(a, b, "WpmzoаPirmzoаWomrypeTevwleoZFewwicr");

            
        }

        static bool ValidCheck(string monthyearofend, string cardnum, List<string> history)
        {
            
            var date = Regex.Split(DateTime.Today.ToString(), @"\.");
            var carddate = Regex.Split(monthyearofend, @"\/");
            if ((int.Parse(date[2].Substring(2, 2)) == int.Parse(carddate[1]) && (int.Parse(date[1]) < int.Parse(carddate[0]))) || int.Parse(date[2].Substring(2, 2)) < int.Parse(carddate[1]));
                return true;
            history.Add($"{cardnum} пополнение отменено, карта просрочена\n"); 
            Console.WriteLine("Действие невозможно,ваша карта просрочена");
            return false;
        }
        static bool CheckBanknotes(Dictionary<string, int> storage, Dictionary<string, int> caset, string num, List<string> history)
        {
            foreach (var item in storage)
            {
                if (!caset.ContainsKey(item.Key) || item.Value < 1)
                {
                    history.Add($"{num}: пополнение отменено, введена некорректная сумма\n");
                    Console.WriteLine($"Вы пытаетьсь совершить незаконную операцию. Ожидайте приезда сотрудников урегуриующих проблему.");
                    return false;
                }
            }
            return true;
        }
        
        static Dictionary<string, int> GetBanknotes(string banknotes)
        {
            var arr = Regex.Split(banknotes, @"\s+").Select(x => x.ToString()).ToArray();
            var storage = new Dictionary<string, int>();
            foreach (var item in arr)
            {
                var b = Regex.Split(item, @",").Select(item => item.ToString()).ToArray();
                if (b.Length == 2 && !Regex.Match(b[0], @"\D").Success && !Regex.Match(b[1], @"\D").Success)
                {
                    if (storage.ContainsKey(b[0]))
                        storage[b[0]] += int.Parse(b[1]);
                    else storage[b[0]] = int.Parse(b[1]);
                }
                else throw new ArgumentException("Неправильный формат ввода купюр");
            }
            return storage;
        }
        static long CashSum(Dictionary<string, int> storage)
        {
            long sum = 0;
            foreach (var item in storage)
                sum += int.Parse(item.Key) * item.Value;
            return sum;
        }
        static double AddFee(string bankissuer, string bank, string cardnum, List<string> history)
        {
            if (bankissuer == bank)
                return 1.00;
            else
            {
                Console.WriteLine("Банкоматом владеет другой банк, на операцию будет ввелена комиссия");
                history.Add($"{cardnum}: изменена сумма пополнения, введена комиссия\n");
                return 0.95;
            }
        }
        static void WithdrawalATM(Dictionary<string, int> storage, Dictionary<string, int> casette)
        {
            foreach (var item in storage)
                casette[item.Key] += item.Value;
        }
        static void Replenishment(Card card, ATM atm, Dictionary<string, int> banknotes)
        {
            if (CheckBanknotes(banknotes, atm.Cassette, card.CardNum, atm.History))
            {
                if (ValidCheck(card.MonthYearOfEnd, card.CardNum, atm.History))
                {
                    double AddedMoney = CashSum(banknotes) * AddFee(card.BankIssuer, atm.Bank, card.CardNum, atm.History);
                    card.Balance += AddedMoney;
                    WithdrawalATM(banknotes, atm.Cassette);
                    Console.WriteLine("Операция успешно завершена!");
                    atm.History.Add($"{card.CardNum}: пополнение на {AddedMoney}, операция успешно завершена\n");
                }
            }
        }
        static int CheckSum(string s)
        {
            if (!Regex.Match(s, @"\D").Success || s != "")
                if (int.Parse(s) % 50 == 0)
                    return int.Parse(s);
            throw new ArgumentException("Сумма для снятия введена в неправильном формате");
        }
        static bool CanGetMoney(int balance, Dictionary<string, int> dict, string num, List<string> history)
        {
            var count = 0;
            foreach (var x in dict)
            {
                for (var i = 0; i < x.Value; i++)
                    if (count + int.Parse(x.Key) <= balance)
                        count += int.Parse(x.Key);
            }
            if (balance == count)
                return true;
            Console.WriteLine("Банкомат не может выдать данную сумму!");
            history.Add($"{num}: снятие => невозможно выдать сумму");
            return false;
        }
        static void GiveMoney(int sum, Dictionary<string, int> storage)
        {
            var count = 0;
            foreach (var item in storage)
            {
                for (var i = 0; i < item.Value; i++)
                    if (count + int.Parse(item.Key) <= sum)
                    {
                        storage[item.Key] -= 1;
                        count += int.Parse(item.Key);
                    }
            }
        }
        static void Withdrawal(Card card, ATM atm, int sum)
        {
            if (ValidCheck(card.MonthYearOfEnd, card.CardNum, atm.History))
            {
                if (atm.CashAmount >= sum)
                {
                    if (card.Balance >= sum)
                    {
                        if (CanGetMoney(sum, atm.Cassette, card.CardNum, atm.History))
                        {
                            GiveMoney(sum, atm.Cassette);
                            card.Balance -= sum * AddFee(card.BankIssuer, atm.Bank, card.CardNum, atm.History);
                            Console.WriteLine("Операция успешно завершена!");
                            atm.History.Add($"{card.CardNum}: снитие {sum}=> операция успешно завершена\n");
                        }
                    }
                    else
                        Console.WriteLine("Недостаточно средств на карте!");
                }
                else
                {
                    Console.WriteLine("В банкомете недостаточно средств!");
                    atm.History.Add($"{card.CardNum}: снятие => недостаточно средств в банкомате");
                }
            }
        }
        static void PickUp(Card card, ATM atm, string safetycode)
        {
            if (safetycode.Length == atm.SafetyKey.Length)
            {
                int flag = 1;
                for (int i = 0; i < safetycode.Length; i++)
                {
                    if (safetycode[i] - 4 != atm.SafetyKey[i])
                        flag = 0;
                }
                if (flag == 1)
                {
                    var count = 0;
                    foreach (var x in atm.Cassette)
                        count += x.Value;
                    count /= 7;
                    foreach (var x in atm.Cassette)
                        atm.Cassette[x.Key] = count;
                    Console.WriteLine($"{atm.History}");
                    atm.History.Clear();
                }
                else
                {
                    for (int i = 0; i < safetycode.Length; i++)
                    {
                        Console.WriteLine($"{safetycode[i] - 4} {atm.SafetyKey[i] - 0}");
                    }
                }
            }
        }
    }
}