﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeworkATM
{
    internal class ATM
    {
        public long ID;
        public string Bank { get; }
        public Dictionary<string, int> Cassette;
        public List<string> History;
        public string SafetyKey;

        

        public long CashAmount
        {
            get 
            {
                long sum = 0;
                foreach (var item in Cassette)
                    sum += int.Parse(item.Key) * item.Value;
                return sum;
            }

        }
        
        public ATM(string bank)
        {
            try
            {
                if (Bank == "")
                    throw new ArgumentException("Field can't be empty");
            }
            catch { }

            var r = new Random();
            ID = r.Next(1,10000000);
            this.Bank = bank;
            Cassette = new Dictionary<string, int>() { ["100"] = 1000, ["200"] = 1000,
                ["500"] = 1000, ["1000"] = 1000, ["2000"] = 1000, ["5000"]=1000 };
            History = new List<string>();
            SafetyKey = "YeahRight";
                
        }

        public override string ToString()
        {
            string cass = "";
            foreach (var item in Cassette)
                cass += $"В банкомате {item.Value} купюр номиналом в {item.Key} рублей\n";
            string hist = "";
            foreach (var x in History)
                hist += $"{x} + \n";
            return $"Id банкомата {ID}, банк {Bank}, \n{cass} \n{hist} \nКлюч безопасности - {SafetyKey}";
        }
        

    }
}
